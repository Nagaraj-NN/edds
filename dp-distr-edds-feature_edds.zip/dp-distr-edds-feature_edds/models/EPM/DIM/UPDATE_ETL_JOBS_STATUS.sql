-- ============================================================
-- CONVERSION SUMMARY
-- SOURCE FILE       : LOAD_DWMS_ACTUAL_DATA.sql
-- MAPPING NAME      : UPDATE_ETL_JOBS_PARMS
-- TARGET TABLE      : CRPDB01_DEV_SANDBOX.EPMADM.PS_Z_ETL_JOBS
-- AUTOSYS_JOB_NAME  : LOAD_DWMS_ACTUAL_DATA_ASYS
-- MATERIALIZATION   : view
-- ============================================================

{{ config(
    materialized='view',
    meta={"session_name": "UPDATE_ETL_JOBS_PARMS"},
    pre_hook=[
        log_model_start(this, 'LOAD_DWMS_ACTUAL_DATA_ASYS'),
        "UPDATE {{ source('CRPDB01_EPMADM', 'PS_Z_ETL_JOBS') }} /* CRPDB01_DEV_SANDBOX.EPMADM.PS_Z_ETL_JOBS */ AS TGT
        SET
        Z_RUN_PARM1 = CASE
            WHEN NULLIF(TRIM(TGT.STATUS), '') = 'C'
                THEN NULLIF(TRIM(TGT.Z_RUN_PARM2), '')
            ELSE NULLIF(TRIM(TGT.Z_RUN_PARM1), '')
            END,
        Z_RUN_PARM2 = CASE
                WHEN NULLIF(TRIM(TGT.STATUS), '') = 'C'
                    THEN TO_CHAR(CURRENT_TIMESTAMP(), 'YYYY-MM-DD-HH24.MI.SS')
                ELSE NULLIF(TRIM(TGT.Z_RUN_PARM2), '')
            END,
        Z_RUN_PARM3 = NULLIF(TRIM(TGT.Z_RUN_PARM3), ''),
        Z_RUN_PARM4 = NULLIF(TRIM(TGT.Z_RUN_PARM4), ''),
        Z_RUN_PARM5 = COALESCE(TRIM(TGT.Z_RUN_PARM5), ''),
        STATUS = 'R'
        WHERE NULLIF(TRIM(TGT.JOB_ID), '') = 'DWMS'"
    ],
    post_hook=[
        log_model_end(this, 'LOAD_DWMS_ACTUAL_DATA_ASYS')
    ]
) }}

SELECT 'This model executes the UPDATE_ETL_JOBS_PARMS update mapping for PS_Z_ETL_JOBS' AS Model_Description
