-- ============================================================
-- CONVERSION SUMMARY
-- SOURCE FILE       : LOAD_DWMS_ACTUAL_DATA.sql
-- MAPPING NAME      : INS_DWMS_SOURCE_STATUS
-- TARGET TABLE      : DWMRP_DEV_SANDBOX.DWMR.DWMS_SOURCE_STATUS
-- AUTOSYS_JOB_NAME  : LOAD_DWMS_ACTUAL_DATA_ASYS
-- MATERIALIZATION   : table
-- ============================================================

{{ config(
    database='DWMRP_DEV_SANDBOX',
    schema='DWMR',
    alias='DWMS_SOURCE_STATUS',
    materialized='incremental',
    incremental_strategy='append',
    pre_hook=[
        log_model_start(this, 'LOAD_DWMS_ACTUAL_DATA_ASYS')
    ],
    post_hook=[
        log_model_end(this, 'LOAD_DWMS_ACTUAL_DATA_ASYS')
    ]
) }}


WITH SQ_DWMS_SOURCE_STATUS AS
(
    SELECT
        MAX(SRC.TS_RUN) AS TS_RUN,
        MAX(SRC.LOAD_DATE) AS LOAD_DATE
    FROM {{ this }} /* DWMRP_DEV_SANDBOX.DWMR.DWMS_SOURCE_STATUS */ AS SRC
)
SELECT
    'EPM' AS SOURCE_NAME,
    SQ.TS_RUN,
    'Y' AS IND_SUCCESS,
    SQ.LOAD_DATE
FROM SQ_DWMS_SOURCE_STATUS AS SQ
